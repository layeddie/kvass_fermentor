## Installation

Run `nix develop` and flash your Raspberry Pi with `mix firmware.gen.script`.